## 

```
@article{
  rebouccas2018reliable,
  title={A reliable approach for detection of incipient faults of short-circuits in induction generators using machine learning},
  author={Rebou{\c{c}}as Filho, Pedro Pedrosa and Nascimento, Navar MM and Sousa, Igor R and Medeiros, Cl{\'a}udio MS and de Albuquerque, Victor Hugo C},
  journal={Computers \& Electrical Engineering},
  volume={71},
  pages={440--451},
  year={2018},
  publisher={Elsevier}
}
```
