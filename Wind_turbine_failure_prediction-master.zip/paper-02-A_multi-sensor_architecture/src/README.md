
# Incorportate into the transforms.py a structure from another project  - DONE
# Create selectors for mutiples features types - DONE
# Create scalers for mutiples features types - DONE

# TODO: Create Pipelines and Feature Union

## Pipes
### SENSORC
> For each feature set
- ALL FEATURES
- FEATURES AS SAMPLES

total = 12

> For each feature set
### SENSORV
- ALL FEATURES
- FEATURES AS SAMPLES

total = 12
> For each feature set
### SENSORA
- ALL FEATURES

total = 3


